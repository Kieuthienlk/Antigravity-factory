---
description: Auto-execute với Master Controller - tự động phát hiện và áp dụng skills/workflows phù hợp
---

# /auto - Intelligent Factory Automation

> **Mục đích**: Để AI tự động phân tích "Nên làm gì?" thay vì bạn phải ra lệnh chi tiết.

---

## 🤖 1. Auto-Analysis Protocol

Khi gõ `/auto` kèm theo yêu cầu (hoặc không), hệ thống sẽ chạy:

1.  **Intent Recognition**: Phân tích ý định (Fix bug / New Feature / Question).
2.  **Mode Selection**: Chọn 1 trong 3 chế độ:
    *   🥷 **Ninja**: Cho task nhỏ, script, prototype.
    *   👥 **Squad**: Cho feature vừa, team nhỏ.
    *   🏭 **Factory**: Cho production, core system.
3.  **Skill Loading**: Tự động load skills cần thiết.

---

## 📝 2. Cách Dùng

### Scenarios:

**Case 1: Muốn fix nhanh cái lỗi CSS**
> `/auto` banner bị lệch trái, fix nhanh dùm

**Case 2: Muốn xây dựng module thanh toán an toàn**
> `/auto` build payment gateway tích hợp Stripe

**Case 3: Không biết bắt đầu từ đâu**
> `/auto` review project này xem cần làm gì tiếp

---

## ⚙️ 3. Under the Hood

Workflow này sẽ kích hoạt `@[skills/master-controller]` và thực hiện:

```python
if urgency == HIGH or complexity == LOW:
    return "Ninja Mode" (Skip Audit)
elif impact == CRITICAL:
    return "Factory Mode" (Full Audit)
else:
    return "Squad Mode" (Balanced)
```
