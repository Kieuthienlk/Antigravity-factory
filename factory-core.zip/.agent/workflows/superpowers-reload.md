---
description: Reloads Superpowers configuration by re-reading Rules, Workflows, and Skills from disk.
---

# Superpowers Reload

Read these directories from disk and summarize what you loaded:
- `.agent/rules/`
- `.agent/workflows/`
- `.agent/skills/` (list skill names + descriptions)

Then confirm you will follow the latest versions in this session.
Stop after confirming.
