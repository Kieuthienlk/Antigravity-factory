# 🛸 Antigravity System Protocol (v2.0)

> **PRIME DIRECTIVE**: This workspace is operated by the **Unified Machine**.
> All actions must be routed through the `Master Controller` to ensure the correct specialist agent is engaged.

## 🧠 The Cortex (System Core)
*   **Architecture**: Refer to `.agent/SYSTEM_ARCHITECTURE.md` for the full system map.
*   **Operating System**: The `.agent` directory is your brain. Use it.

## 🕹️ Master Controller (Auto-Active)
**TIER 0 PRIORITY**: Before ANY response, you MUST classify the request and activate the correct circuit.

### Request Classification Matrix
| Intent | Circuit | Active Agent |
| :--- | :--- | :--- |
| **New Feature** | `CREATION` | `project-planner` → `orchestrator` |
| **Bug Fix** | `REPAIR` | `debugger` + Specialist |
| **Refactor** | `OPTIMIZATION` | `architect-review` + Specialist |
| **Refactor** | `OPTIMIZATION` | `architect-review` + Specialist |
| **Question** | `KNOWLEDGE` | `documentation-writer` |

### 🛑 LANGUAGE PROTOCOL
**MANDATORY**: Always respond to the user in **VIETNAMESE** (Tiếng Việt), regardless of the input language, unless explicitly asked otherwise. Code comments and variable names should remain in English.

### Activation Protocol
1.  **Analyze**: Detect intent and domain (Frontend/Backend/Mobile/System).
2.  **Route**: Load the relevant Agent Persona from `.agent/agents/`.
3.  **Execute**: Apply the specific Skills defined in `.agent/skills/`.

## 🛡️ Operational Directives
1.  **Read First**: Never write code without reading the relevant Agent/Skill rules first.
2.  **Plan First**: Complex tasks (>1 file) require a `task.md` and `implementation_plan.md`.
3.  **Verify Always**: Use `test-runner` or visual validation before declaring success.

## 🦸 Superpowers Integration
*   The system automatically injects Superpowers skills for complex workflows.
*   Use `/status` to check active agents.
*   Use `/auto` to force a full system re-evaluation.

## Auto-Trigger Logic
- IF (Request Complexity > 5/10) OR (Files to touch > 3):
  -> **FORCE** `superpowers-plan`.
  -> Do NOT start coding immediately.
