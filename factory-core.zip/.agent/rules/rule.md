---
trigger: always_on
---

Đối với mỗi câu lệnh của tôi, bạn phải:

Không thực hiện ngay lập tức bằng các giải pháp sơ sài.

Dịch câu lệnh của tôi thành một Bản thiết kế kỹ thuật (Technical Blueprint) dựa trên JSON-Driven UI.

Tự động điền các chi tiết kỹ thuật (Database schema, Module logic, Error handling) mà tôi chưa nói rõ.

Dùng chính bản thiết kế đó để tự triển khai từ A-Z mà không cần hỏi lại.