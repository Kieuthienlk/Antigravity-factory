# SPECIALIZATION-GAME.MD - Game Factory Department

> **Status**: ACTIVE
> **Type**: SPECIALIZED DEPARTMENT
> **Lead Agent**: `@[agents/game-developer]`

---

## 🎮 1. DEPARTMENT OVERVIEW

This department is a specialized factory unit dedicated to **Game Development** & **Immersive Experiences**.
When activated, it overrides standard web/backend protocols to prioritize performance, graphics, and real-time logic.

### 🎯 Core Focus
- **Engines**: Unity, Godot, Unreal Engine, WebGL (Three.js/R3F).
- **Architecture**: ECS (Entity Component System), Event-Driven Game Loops.
- **Domains**: 2D/3D Games, Metaverse, Interactive Web, Simulation.

---

## 🛠️ 2. SPECIALIZED ARSENAL (Skills)

When in **Game Mode**, the Master Controller prioritizes these skills:

### 🌟 Tier S (Core Engines)
- `unity-developer`: Unity 6, C#, URP/HDRP.
- `unreal-engine-cpp-pro`: Unreal 5.x, C++, Blueprints.
- `godot-gdscript-patterns`: Godot 4, GDScript.
- `game-development`: General game orchestrator.

### 🎨 Tier A (Graphics & Web)
- `3d-web-experience`: Three.js, R3F, WebGL shaders.
- `threejs-skills`: Low-level Three.js optimization.
- `web-performance-optimization`: 60FPS targets.

### 🏗️ Tier B (Architecture & Backend)
- `unity-ecs-patterns`: DOTS, Jobs System.
- `minecraft-bukkit-pro`: Server plugins.
- `backend-specialist` (Support role for Game Servers).

---

## ⚙️ 3. OPERATING PROTOCOLS

### A. The "60 FPS" Rule
- **Performance First**: Mọi đoạn code gameplay phải được tối ưu bộ nhớ và CPU. Tránh Garbage Collection trong Update Loop.
- **Assets**: Luôn kiểm tra size texture, polygon count.

### B. Game Loop Architecture
- Không dùng MVC truyền thống của Web.
- Sử dụng **ECS** hoặc **Component-based** architecture.
- Quản lý State bằng Singleton Managers hoặc Event Bus.

### C. Testing Standard
- **Play Mode Tests**: Bắt buộc test gameplay logic.
- **Network Simulation**: Test lag/disconnect cho game online.

---

## 🔄 4. INTELLIGENT ROUTING TRIGGER

**Activate this department when User asks about:**
> "Unity", "Godot", "Unreal", "Game", "Nhân vật", "Vật phẩm", "Physics", "Shader", "3D", "Canvas", "WebGL", "Vượt ải", "Thần thú".

---
