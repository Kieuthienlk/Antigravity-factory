# Development Rules

## 1. UI Architecture & Layering
- **Z-Index Management**:
  - Main Popups: z-index 10-50.
  - Sub-Popups (Soldier, etc.): z-index 50-99.
  - Critical Controls (e.g., Tab Navigation `btnRow`): Must always be above content layers (z-index >= 100) or handle click propagation correctly.
  - Overlays: Use semi-transparent backgrounds for modal blocking, ensuring interaction is blocked *only* where intended.
- **Pointer Events**:
  - Containers should generally use `pointer-events: none` to pass clicks through to underlying layers unless they specificially need to block interaction (e.g., modals).
  - Interactive elements (Buttons, Inputs) must explicitly set `pointer-events: auto`.
  - Groups: If a group container holds interactive elements but shouldn't block the whole screen, set `pointer-events: none` on the group and `auto` on children.

## 2. Resource & Texture Loading
- **Initialization**:
  - ALWAYS ensure configuration (JSON) and assets (Atlases) are fully loaded before attempting `render()`.
  - Use `async/await` for `init()` sequences.
  - Check for existence of textures/frames before applying. Log errors if missing but do not crash the UI.
- **Texture Application**:
  - Use helper functions (`applySprite`) consistently.
  - When applying textures from JSON configuration, verify `textureId` against loaded atlases.
  - Ensure Button textures are applied to the correct properties (background-image).

## 3. Code Structure & Maintenance
- **Separation of Concerns**: Keep Logic separate from Rendering helpers.
- **Error Handling**: Graceful degradation when assets fail to load.
- **Verification**: Always verify visual output (via manual test steps) after modifying rendering logic.
- **Backup Rule**: ALWAYS backup a file before performing a complete rewrite or major refactor (e.g., `cp file.js file.js.bak`).
- **Data-Driven Coding**:
  - Always read the JSON data *first* (e.g., `soldiers.json`) to understand the exact field names (e.g., `Icon`, `File`, `Id`) before determining logic.
  - Do not guess data structures. 
- **Texture Lookup Logic**:
  - Implement a fallback mechanism: `id` -> `btn+id` -> `icon path from data`.
  - Use `warn` logs instead of crashing on missing textures.
- **Global Exports**:
  - ALWAYS expose the main UI class to the global scope at the end of the file (e.g., `window.Soldier = Soldier;`).
  - Without this, the game controller cannot instantiation the class.
