# FACTORY-MODE.MD - Strict Production Protocol

> **Status**: ACTIVE
> **Mode**: SOFTWARE-FACTORY (Strict)

---

## 🏭 1. FACTORY OPERATING MODEL

This project operates as a **Software Factory**. We do not "hack" code; we engineer products.

### The 3 Laws of the Factory:
1.  **No Unverified Output**: Every line of code must pass the `quality-inspector` gate.
2.  **PDCA is Law**: Plan -> Do -> Check -> Act. No jumping straight to "Do".
3.  **Zero Broken Windows**: Fix lint errors, warnings, and security issues immediately.

---

## 🛡️ 2. QUALITY GATES (MANDATORY)

Before ANY `notify_user` to announce completion, you MUST run:

```bash
# 1. Self-Check (Developer)
python .agent/scripts/checklist.py .

# 2. Gatekeeper Check (Quality Inspector)
python .agent/scripts/checklist.py . --check=security,lint,test
```

### Passing Criteria:
- [ ] Security Scan: 0 High/Critical issues
- [ ] Lint: 0 Errors
- [ ] Tests: 100% Pass for affected modules
- [ ] Build: Successful

---

## 🤖 3. AGENT ROLES IN FACTORY

| Agent | Factory Role |
|-------|--------------|
| `orchestrator` | **Plant Manager**. Assigns tasks, ensures flow. |
| `project-planner` | **Design Studio**. Creates the blueprint (`task.md`). |
| `cloud-architect` | **Infrastructure**. Manages the assembly line servers. |
| `quality-inspector`| **Quality Control**. Rejects defects before delivery. |
| `codebase-expert` | **Maintenance**. Refactors and cleans the machinery. |

---

## ⚠️ 4. OVERRIDE PROTOCOL

If a critical hotfix is needed (`/debug` or `fix`):
1.  Announce: "🚨 EMERGENCY FIX - BYPASSING STANDARD GATE"
2.  Execute fix.
3.  Post-fix: IMMEDIATE Audit using `/audit` to verify no regression.

---
*Factory Mode is NON-NEGOTIABLE for production-grade software.*
