# 🏭 DYNAMIC FACTORY REGISTRY (DEPARTMENTS.MD)

> **Status**: ACTIVE
> **Type**: CORE PROTOCOL
> **Controller**: `master-controller`

---

## 🗺️ FACTORY SCHEMA (Sơ đồ Nhà Máy)

```mermaid
graph TD
    User([User Request]) --> MC{Master Controller<br/>(Vibe Check & Scan)}
    
    MC -- "Game/Unity/3D" --> G[🎮 Game Studio]
    MC -- "Web/Mobile/App" --> W[🌐 Web & Mobile Div]
    MC -- "Infrastructure/API" --> C[⚙️ Core Engineering]
    MC -- "Security/Audit" --> S[🛡️ Defense & Quality]
    MC -- "Plan/Strategy" --> P[🧠 Product & Strategy]

    subgraph "CROSS-OPS (Hỗ trợ chéo)"
        G -. "Need DB/API" .-> C
        W -. "Need Audit" .-> S
        C -. "Need UI" .-> W
    end

    G --> Output[Game Product]
    W --> Output[App/Web Product]
    C --> Output[Infrastructure]
```

---

## 🏢 DEPARTMENT REGISTRY (Danh bạ Bộ Phận)

### 1. 🎮 Game Studio (Priority: High)
- **Triggers**: `unity`, `godot`, `unreal`, `shader`, `3d`, `physics`.
- **Head Agent**: `game-developer`.
- **Special Rule**: `rules/specialization-game.md` (60 FPS Protocol).

### 2. 🌐 Web & Mobile Div
- **Triggers**: `react`, `nextjs`, `flutter`, `ios`, `android`, `css`, `tailwind`.
- **Head Agent**: `frontend-specialist` (Web) / `mobile-developer` (Mobile).
- **Special Rule**: `rules/frontend-design.md` (Pixel Perfect).

### 3. ⚙️ Core Engineering
- **Triggers**: `backend`, `api`, `database`, `docker`, `aws`, `cicd`, `terraform`.
- **Head Agent**: `backend-specialist` / `cloud-architect`.
- **Special Rule**: `rules/clean-code.md` (Solid/Scalable).

### 4. 🛡️ Defense & Quality
- **Triggers**: `security`, `hack`, `audit`, `test`, `bug`, `debug`.
- **Head Agent**: `security-auditor` / `quality-inspector`.
- **Special Rule**: `rules/security.md` (Zero Trust).

### 5. 🧠 Product & Strategy
- **Triggers**: `plan`, `analyze`, `seo`, `market`, `idea`, `write`.
- **Head Agent**: `product-manager` / `orchestrator`.
- **Special Rule**: `rules/brainstorming.md` (Deep Dive).

---

## 🔄 OPERATING PRINCIPLES (Nguyên tắc Vận Hành)

### 1. Dynamic Loading (Tải động)
Nhà máy **KHÔNG** tải tất cả bộ phận cùng lúc.
- Khi User hỏi về Game -> Chỉ bật đèn và máy móc ở **Game Studio**.
- Các bộ phận khác chuyển sang chế độ **Standby**.

### 2. Cross-Ops (Hỗ trợ chéo)
Không bộ phận nào là ốc đảo.
- Nếu **Game Studio** cần lưu dữ liệu Online -> Master Controller sẽ tạm thời đánh thức **Core Engineering** để thiết kế Database, sau đó Core Eng lại lui về sau màn.
- **Rule**: "Expertise Borrowing" (Mượn chuyên gia) thay vì tự làm bừa.

### 3. Scale-Adaptive (Tùy biến quy mô)
- **Ninja Mode**: Một Agent làm hết (Solo).
- **Factory Mode**: Triệu hồi cả dây chuyền (Head + Specialist + Auditor).
