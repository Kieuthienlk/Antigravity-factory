import os
import zipfile
from pathlib import Path

MAX_SIZE_MB = 24  # Keep under 25MB for safety
DIST_DIR = Path("_factory_dist")
AGENT_DIR = Path(".agent")

def get_dir_size(path):
    total = 0
    for p in path.glob('**/*'):
        if p.is_file():
            total += p.stat().st_size
    return total / (1024 * 1024)

def zip_dir(zip_name, source_dir, include_patterns=None, exclude_patterns=None):
    zip_path = DIST_DIR / zip_name
    print(f"📦 Zipping {zip_name}...")
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = Path(root) / file
                arcname = file_path.relative_to(Path("."))
                
                # Filter logic
                if exclude_patterns and any(ex in str(arcname) for ex in exclude_patterns):
                    continue
                if include_patterns:
                    # Specific inclusion logic if needed
                    pass
                
                zf.write(file_path, arcname)
    
    size = zip_path.stat().st_size / (1024 * 1024)
    print(f"   -> Size: {size:.2f} MB")
    return size

def main():
    if not DIST_DIR.exists():
        DIST_DIR.mkdir()

    # 1. Zip Core (Everything except skills)
    print("=== Phase 1: Core Packaging ===")
    zip_path = DIST_DIR / "factory-core.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(AGENT_DIR):
            if "skills" in root.split(os.sep): 
                continue # Skip skills directory content
            
            for file in files:
                file_path = Path(root) / file
                if not file_path.name.endswith(('.log', '.pid')):
                    zf.write(file_path, file_path.relative_to(Path(".")))
    print(f"✅ Core Zipped: {zip_path.stat().st_size / 1024 / 1024:.2f} MB")

    # 2. Zip Skills in chunks
    print("\n=== Phase 2: Skills Partitioning ===")
    skills_dir = AGENT_DIR / "skills"
    all_skills = sorted([d for d in skills_dir.iterdir() if d.is_dir()])
    
    current_part = 1
    current_zip = None
    current_size = 0
    
    # Initialize first zip
    zip_name = f"factory-skills-part{current_part}.zip"
    current_zip = zipfile.ZipFile(DIST_DIR / zip_name, 'w', zipfile.ZIP_DEFLATED)
    
    for skill in all_skills:
        # Check skill size roughly
        skill_size = get_dir_size(skill)
        
        # If current zip + skill > limit, cycle to new zip
        # Note: Compressed size is smaller, but we check raw for safety or check actual zip size
        
        # Better approach: Write to zip, check size, if too big, close and start new?
        # Hard to rollback. Let's estimate: Text compresses ~3x-5x. 
        # But safest is to just start a new zip if we accumulate > 40MB raw (assuming 50% compress)
        
        # Let's use a conservative raw limit of 30MB per chunk to ensure < 25MB zip
        if current_size + skill_size > 30: 
            current_zip.close()
            print(f"   -> {zip_name} created.")
            
            current_part += 1
            current_size = 0
            zip_name = f"factory-skills-part{current_part}.zip"
            current_zip = zipfile.ZipFile(DIST_DIR / zip_name, 'w', zipfile.ZIP_DEFLATED)
        
        # Add skill to current zip
        for root, dirs, files in os.walk(skill):
            for file in files:
                file_path = Path(root) / file
                current_zip.write(file_path, file_path.relative_to(Path(".")))
        
        current_size += skill_size
    
    if current_zip:
        current_zip.close()
        print(f"   -> {zip_name} created.")

    print("\n✅ Splitting Complete!")

if __name__ == "__main__":
    main()
