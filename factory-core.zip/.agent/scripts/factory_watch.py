import time
import os
import sys
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import subprocess

class FactoryHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.is_directory:
            return
        
        filepath = event.src_path
        filename = os.path.basename(filepath)
        extension = os.path.splitext(filename)[1]

        # Ignore non-code files and artifacts
        if "artifacts" in filepath or ".git" in filepath or "node_modules" in filepath:
            return

        print(f"\n[Factory Watch] Detected change in: {filename}")

        if extension in ['.js', '.ts', '.tsx', '.py']:
            self.trigger_quality_control(filepath)
        elif extension == '.json':
            self.validate_schema(filepath)

    def trigger_quality_control(self, filepath):
        print(f"  -> Triggering Quality Control for {filepath}...")
        try:
            # Run checklist.py for the specific file or directory
            result = subprocess.run(
                ["python", ".agent/scripts/checklist.py", filepath],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                print("  -> [QC] PASSED ✅")
            else:
                print(f"  -> [QC] FAILED ❌\n{result.stdout}\n{result.stderr}")
        except Exception as e:
            print(f"  -> [QC] Error running check: {e}")

    def validate_schema(self, filepath):
        print(f"  -> Validating Schema for {filepath}...")
        try:
            result = subprocess.run(
                ["python", ".agent/scripts/checklist.py", filepath, "--check=schema"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                print("  -> [Schema] PASSED ✅")
            else:
                print(f"  -> [Schema] FAILED ❌\n{result.stdout}")
        except Exception as e:
            print(f"  -> [Schema] Error: {e}")

if __name__ == "__main__":
    path = "." if len(sys.argv) < 2 else sys.argv[1]
    event_handler = FactoryHandler()
    observer = Observer()
    observer.schedule(event_handler, path, recursive=True)
    print(f"🏭 Factory Watchdog started. Monitoring {os.path.abspath(path)}...")
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
