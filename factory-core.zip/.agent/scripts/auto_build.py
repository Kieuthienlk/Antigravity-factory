import os
import subprocess
import sys

def build_web_client(app_path):
    print(f"🚀 Starting Auto-Build for: {app_path}")
    
    if not os.path.exists(app_path):
        print(f"❌ Error: Path {app_path} does not exist.")
        return

    # Check for package.json
    if not os.path.exists(os.path.join(app_path, "package.json")):
        print("❌ Error: No package.json found. Is this a Node.js app?")
        return

    try:
        # Install dependencies if needed (simplified check)
        if not os.path.exists(os.path.join(app_path, "node_modules")):
            print("📦 Installing dependencies...")
            subprocess.run(["npm", "install"], cwd=app_path, check=True, shell=True)

        # Run Build
        print("🔨 Building application...")
        subprocess.run(["npm", "run", "build"], cwd=app_path, check=True, shell=True)
        print("✅ Build Successful!")

    except subprocess.CalledProcessError as e:
        print(f"🔥 Build Failed: {e}")

if __name__ == "__main__":
    target_app = "Apps/web_client" # Default target
    if len(sys.argv) > 1:
        target_app = sys.argv[1]
    
    build_web_client(target_app)
