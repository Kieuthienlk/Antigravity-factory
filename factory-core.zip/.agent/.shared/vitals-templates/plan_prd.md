# 📋 [PROJECT_NAME] - Implementation Plan (PRD)
**Author**: Project Planner Agent
**Phase**: PLAN
**Status**: Pending Approval

## 1. Context & Objectives
- **Problem**: (Mô tả vấn đề)
- **Goal**: (Mô tả mục tiêu)
- **Target Audience**: (Đối tượng sử dụng)

## 2. Technical Architecture
- **Tech Stack**: (Frontend/Backend/DB)
- **External APIs**: (Stripe, Maps, etc.)

## 3. Detailed Tasks (The Roadmap)
- [ ] **Task 1**: ...
- [ ] **Task 2**: ...

## 4. Success Criteria
- [ ] Performance > 90
- [ ] Security scan passed
- [ ] Mobile-first verified
