# 🧠 Psychological Triggers for CRO

Tập hợp các đòn bẩy tâm lý để tăng tỷ lệ chuyển đổi.

### 1. LIFT Model
- **Value Proposition**: Tại sao khách hàng nên mua từ bạn? (Quan trọng nhất).
- **Relevance**: Nội dung có khớp với kỳ vọng của người dùng không?
- **Clarity**: Thông điệp và Call-to-Action có rõ ràng không?
- **Urgency**: Tạo sự khan hiếm (Giới hạn thời gian/số lượng).
- **Anxiety**: Giảm bớt sự lo lắng (Bảo hành, Đánh giá thật).
- **Distraction**: Loại bỏ các yếu tố gây xao nhãng khỏi Landing Page.

### 2. Social Proof (Bằng chứng xã hội)
- Case Studies thực tế.
- Logo các đối tác/khách hàng lớn.
- Testimonials kèm ảnh và chức vụ thật.

### 3. Fitts's Law
- Nút bấm quan trọng phải To và nằm ở vị trí dễ chạm tới.
