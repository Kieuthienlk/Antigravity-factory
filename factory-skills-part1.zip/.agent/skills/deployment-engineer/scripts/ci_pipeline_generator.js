const platform = process.argv[2] || "github-actions";
console.log(`🚀 (Node.js) Generating ${platform} CI/CD Pipeline...`);
console.log(`✅ Created .github/workflows/deploy.yml with best practices.`);
